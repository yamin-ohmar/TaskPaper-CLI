"""
managers/task_manager.py
Task Manager - Handles data operations related to projects and tasks in a TaskPaper file.
"""

import sys
import os

# importing own modules
sys.path.append(os.path.join(os.path.dirname(__file__), '../'))
from helpers import help_manager as help_mng
from managers import file_manager as file_mng

# Global variable to store the loaded TaskPaper data
loaded_taskpaper_data = {}  # Example: {'Project Name': [Task objects list]} - as dictionary

"""
Helper Functions
"""

# Helper function to load taskpaper data
def load_taskpaper_data(filepath):
    global loaded_taskpaper_data # updating this global variable in this function
    # if the file is not parsed into memory yet, do it now
    if not loaded_taskpaper_data:
        with open(filepath, "r") as file:
            loaded_taskpaper_data = file_mng.parse_taskpaper_file(file.read())

# Helper function to check if the project really exists
def isPrj_exist(project, filepath):
    if project not in loaded_taskpaper_data:
        help_mng.show_error(f"Project '{project}' does not exist in file '{filepath}'.")
        return False
    else:
        return True

# Helper function to display tasks under a specific project
def display_project_tasks(filepath, project_name):
    load_taskpaper_data(filepath)
    project_name = project_name.strip()

    # check if the project name is empty
    if not project_name:
        help_mng.show_error("Error: Invalid project name. The name cannot be empty.")
        return None
    # check if the project really exists
    if not isPrj_exist(project_name, filepath):
        return None

    # get the list of tasks from the project
    tasks = loaded_taskpaper_data[project_name]
    if not tasks:
        help_mng.show_warning(f"There are no tasks under project '{project_name}' in file '{filepath}'.")
        return None

    # display tasks
    print(f"Tasks in project '{project_name}':")
    # use enumerate for indexing (index starts at 1)
    for index, task in enumerate(tasks, start=1):
        print(f" {index}. {task}")

    return tasks

# Helper function to extract info separately 
def parse_edit_input(user_input):
    try:
        # split the input into index and text
        index, new_text = user_input.split(" ", 1)
        return int(index), new_text.strip('" ')
    except (ValueError, IndexError):
        raise ValueError("Invalid input. Format should be: <index> \"<updated text>\"")

"""
End of Helper Functions
"""

# Add a new project to the opened TaskPaper file
def add_project(filepath, project_name):
    global loaded_taskpaper_data # updating this global variable in this function
    load_taskpaper_data(filepath)
    project_name = project_name.strip()
    # check if the project name is empty
    if not project_name:
        help_mng.show_error("Error: Invalid project name. The name cannot be empty.")
    # check if the project is in the existing data
    elif project_name in loaded_taskpaper_data:
        help_mng.show_warning(f"Project '{project_name}' already exists.")
    else:
        # if not, add the project to memory data
        loaded_taskpaper_data[project_name] = []
        print(f"Adding project '{project_name}' to file '{filepath}'...")
        # write data back to the file and check if it is successful
        if (file_mng.write_taskpaper_file(filepath, loaded_taskpaper_data)):
            help_mng.show_success(f"Added project '{project_name}' successfully.")

# List all projects from the opened TaskPaper file
def get_all_projects(filepath):
    load_taskpaper_data(filepath)
    projects = list(loaded_taskpaper_data.keys())
    # check if there are any projects
    if not projects:
        help_mng.show_warning(f"There are no project in file '{filepath}'.")
    else:
        # use enumerate for indexing (index starts at 1)
        for index, project in enumerate(projects, start=1):
            print(f"{index}. {project}")
        help_mng.show_success(f"A total of {index} project(s) listed from file '{filepath}'.")

# Rename an existing project to a new name
def rename_project(filepath, old_name, new_name):
    global loaded_taskpaper_data # updating this global variable in this function
    load_taskpaper_data(filepath) 

    old_name = old_name.strip()
    new_name = new_name.strip()
    
    # check if the old/new project name is empty
    if not old_name or not new_name:
        help_mng.show_error("Error: Invalid project name(s). The name(s) cannot be empty.")
        return
    # check if the project really exists
    if not isPrj_exist(old_name, filepath):
        return
    # check if the new project name already exists
    if new_name in loaded_taskpaper_data:
        help_mng.show_warning(f"Project '{new_name}' already exists in file '{filepath}'. \nPlease choose a different name.")
        return
    
    # renaming the project while preserving the original order of projects 
    ordered_prjs = list(loaded_taskpaper_data.items())
    for index, (prj_name, tasks) in enumerate(ordered_prjs):
        if prj_name == old_name:
            ordered_prjs[index] = (new_name, tasks)  # rename the project and assign its tasks back
            break
    
    # rebuild the dictionary after renaming project orderly
    loaded_taskpaper_data = dict(ordered_prjs)
    print(f"Renaming project '{old_name}' to '{new_name}' in file '{filepath}'...")
    
    # write data back to the file and check if it is successful
    if file_mng.write_taskpaper_file(filepath, loaded_taskpaper_data):
        help_mng.show_success(f"Successfully renamed project '{old_name}' to '{new_name}'.")

# Add a new task to the existing project in the opened TaskPaper file
def add_task(filepath, project_name, task_name):
    global loaded_taskpaper_data # updating this global variable in this function
    load_taskpaper_data(filepath)

    # get rid of extra spaces (beginning and trailing)
    project_name = project_name.strip()
    task_name = task_name.strip()

    # check if the project name or task name is empty
    if not project_name or not task_name:
        help_mng.show_error("Error: Invalid project name (or) task name. The name(s) cannot be empty.")
        return
    
    # check if the project really exists
    if not isPrj_exist(project_name, filepath):
        return
    
    # get the list of tasks from the project
    tasks = loaded_taskpaper_data[project_name]

    # check if the task already exists in that tasks list
    if task_name in tasks:
        help_mng.show_warning(f"Task '{task_name}' already exists in project '{project_name}'.")
        return
   
    # add the task to the project's tasks list
    tasks.append(task_name)
    loaded_taskpaper_data[project_name] = tasks
    print(f"Adding task '{task_name}' to project '{project_name}' in file '{filepath}'...")
    
    # write data back to the file and check if it is successful
    if (file_mng.write_taskpaper_file(filepath, loaded_taskpaper_data)):
        help_mng.show_success(f"Added task '{task_name}' successfully.")

# List tasks under a project from the opened TaskPaper file
def list_tasks(filepath, project_name):
    # use helper function to display tasks
    tasks = display_project_tasks(filepath, project_name)
    if tasks:
        help_mng.show_success(f"A total of {len(tasks)} task(s) listed for project '{project_name}' from file '{filepath}'.")

# Edit task under a project from the opened TaskPaper file
def edit_task(filepath, project_name):
    tasks = display_project_tasks(filepath, project_name)
    if not tasks:
        return  # exit if there are no tasks or the project is invalid

    # prompt user for input (for interactive experience)
    try:
        user_input = input("\nPlease key in the index of the task to be edited and the updated text for that task (e.g., 2 \"Updated Task Text\"): ")
        index, new_text = parse_edit_input(user_input)
    except ValueError as e:
        help_mng.show_error(str(e))
        return

    # check index for validation
    if index < 1 or index > len(tasks):
        help_mng.show_error(f"Error: Invalid index. Must be from 1 to {len(tasks)}.")
        return
    
    # check if the new task name is empty
    if not new_text:
        help_mng.show_error("Error: Invalid updated text. The new task name cannot be empty.")
        return

    # update the task
    old_task = tasks[index - 1] # get old task
    tasks[index - 1] = new_text # set new task
    print(f"Updating the task '{old_task}' to '{new_text}' in file '{filepath}'...")
    
    # write data back to the file and check if it is successful
    if (file_mng.write_taskpaper_file(filepath, loaded_taskpaper_data)):
        help_mng.show_success(f"Task successfully updated in project '{project_name}'.")
