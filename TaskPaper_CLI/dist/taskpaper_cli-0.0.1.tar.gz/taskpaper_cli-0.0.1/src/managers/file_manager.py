"""
managers/file_manager.py
File Manager - Handles file operations like creating TaskPaper files.
"""

import os
import sys
import re
import tempfile

# importing own modules
sys.path.append(os.path.join(os.path.dirname(__file__), '../'))
from helpers import help_manager as help_mng

# define the path for the temporary file (to store opened file path)
TEMP_DATA_FILE = os.path.join(tempfile.gettempdir(), ".taskpaper_tempdata")

# Helper function to save the currently opened file path to a temporary file
def save_opened_file_path(filepath):
    try:
        with open(TEMP_DATA_FILE, "w") as f:
            f.write(filepath)
            help_mng.show_success(f"Successfully loaded filepath '{filepath}' into memory.")
    except Exception as e:
        raise RuntimeError(f"Failed to save opened file path. Reason: {e}")

# Helper function to retrieve the currently opened file path to a temporary file
def get_opened_file_path():
    if os.path.exists(TEMP_DATA_FILE):
        try:
            with open(TEMP_DATA_FILE, "r") as f:
                return f.read().strip()
        except Exception as e:
            raise RuntimeError(f"Failed to retrieve opened file path. Reason: {e}")
    return None

# Helper function to cleanup file name using RegEx
def cleanup_filename(filename):
    # replace invalid chars with underscore and also set the char length
    return re.sub(r'[<>:"/\\|?*]', '_', filename)[:255]

# Helper function to validate directory and creates it
def validate_directory(directory):
    try: # check if it can be created
        if not os.path.exists(directory):
            os.makedirs(directory)
        return True
    except OSError as e: # if not, show error to users with reason
        help_mng.show_error(f"Error: Unable to create or access directory '{directory}'. Reason: {e}")
        return False
    
# Helper function to parse TaskPaper file content into dictionary
def parse_taskpaper_file(content):
    taskpaper_data = {}
    current_project = None

    for line in content.splitlines():
        line = line.strip()
        if line.endswith(":") and not line.startswith("- "):  # Project line
            current_project = line[:-1].strip() # stripping white spaces (start & end) and new line character at the end
            taskpaper_data[current_project] = []
        elif line.startswith("- "):  # Task line
            task_name = line[2:].strip() # stripping white spaces (start & end) and first 2 characters 
            if current_project: # only if there is project
                taskpaper_data[current_project].append(task_name) # tasks will handled later as class object 

    return taskpaper_data

# Helper function to serialize dictionary (data) back to TaskPaper file format
def serialize_taskpaper_data(data):
    lines = []
    for project, tasks in data.items():
        lines.append(f"{project}:")  # add back each project name with a colon
        for task in tasks:
            lines.append(f"  - {task}")  # add back each task with the proper indentation
        lines.append("")  # a blank line for spacing between projects
    return "\n".join(lines)  # Join all lines with newline characters

# creating empty taskpaper files
def create_taskpaper_file(filename, directory):
    # validate filename
    filename = cleanup_filename(filename)
    filename = filename.strip()
    if not filename:
        help_mng.show_error("Error: Invalid file name. The name cannot be empty.")
        return
    
    # Add file extension (.taskpaper)
    if not filename.endswith('.taskpaper'):
        filename += '.taskpaper'

    # validate directory
    if not validate_directory(directory):
        return

     # full path for the file
    filepath = os.path.join(directory, filename)
    absolute_filepath = os.path.abspath(filepath)
    
    # create the file
    file = None
    try:
        file = open(filepath, "x")
        file.write("")
        help_mng.show_success(f"TaskPaper file '{absolute_filepath}' has been created.")
    except FileExistsError: # if the file already exists
        help_mng.show_error(f"Error: '{absolute_filepath}' file already exists.")
    except Exception as e:
        help_mng.show_error(f"{e}")
    finally: # close the file if it was successfully opened
        if file is not None:
            file.close()

# opening and reading existing TaskPaper files
def open_taskpaper_file(filepath):
    # check if it has a `.taskpaper` extension
    if not filepath.endswith('.taskpaper'):
        help_mng.show_warning("Please provide the full file name including the file name extension.")
        return
    
    # check if it points to a valid file
    if not os.path.isfile(filepath):
        help_mng.show_error(f"Error: File '{filepath}' does not exist or is not accessible.")
        return

    save_opened_file_path(filepath) # Save the file path for subsequence commands

# writing edited data into existing taskpaper file
def write_taskpaper_file(filepath, data):
    try:
        with open(filepath, "w") as file:
            # write back all data into the opened taskpaper file
            serialized_content = serialize_taskpaper_data(data)
            file.write(serialized_content)
            return True
    except Exception as e:
        help_mng.show_error(f"Error: Unable to write to file '{filepath}'. Reason: {e}")
        return False
