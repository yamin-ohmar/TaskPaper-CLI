"""
cli/command_handler.py
Command Handler - Routes parsed commands to appropriate managers.
"""
import os
import sys

# importing own modules
sys.path.append(os.path.join(os.path.dirname(__file__), '../'))
from helpers import help_manager as help_mng
from managers import file_manager as file_mng
from managers import task_manager as task_mng

# Helper function for validating the opened file path
def isvalid_opened_file(opened_file_path):
    # check if there is a taskpaper file already opened
    if not opened_file_path:
        help_mng.show_error("No TaskPaper file is currently opened. Use the 'open' command first.")
        return False
    # check if the opened file path is valid
    elif not os.path.exists(opened_file_path):
        help_mng.show_error(f"The file '{opened_file_path}' does not exist. Please use the 'open' command first.")
        return False
    else:
        return True

# handling commands by routing them to managers
def handle_command(args, parser):
    # retrieve the file path from the temp file (if any)
    opened_file_path = file_mng.get_opened_file_path()
    # for 'create' subcommand    
    if args.command == "create":
        # use provided path (make it absolute path first) or default to current directory
        directory = os.path.abspath(args.path) if args.path else os.getcwd()
        file_mng.create_taskpaper_file(args.file_name, directory)
    # for 'open' subcommand    
    elif args.command == "open":
        # use provided path (make it absolute path first)
        filepath = os.path.abspath(args.file_path)
        file_mng.open_taskpaper_file(filepath)
    # for 'add-project' subcommand
    elif args.command == "add-project":
        # check if there is a valid taskpaper file already opened
        if isvalid_opened_file(opened_file_path):
            task_mng.add_project(opened_file_path, args.project_name)
    # for 'list-projects' subcommand
    elif args.command == "list-projects":
        # check if there is a valid taskpaper file already opened
        if isvalid_opened_file(opened_file_path):
            task_mng.get_all_projects(opened_file_path)
    # for 'rename-project' subcommand
    elif args.command == "rename-project":
        if isvalid_opened_file(opened_file_path):
            task_mng.rename_project(opened_file_path, args.old_name, args.new_name)
    # for 'add-task' subcommand
    elif args.command == "add-task":
        if isvalid_opened_file(opened_file_path):
            task_mng.add_task(opened_file_path, args.project, args.task)
    # for 'list-tasks' subcommand
    elif args.command == "list-tasks":
        if isvalid_opened_file(opened_file_path):
            task_mng.list_tasks(opened_file_path, args.project)
    # for 'edit-task' subcommand
    elif args.command == "edit-task":
        if isvalid_opened_file(opened_file_path):
            task_mng.edit_task(opened_file_path, args.project)
    else:
        help_mng.show_help(parser)
