"""
cli/argument_parser.py
Argument Parser - Validates and parses command-line arguments for TaskPaper CLI.
"""

import argparse

# adding arguments (subcommands/options) and their help descriptions
def parse_arguments():
    # a parser object to handle command-line arguments
    parser = argparse.ArgumentParser(prog='TaskPaper', description="TaskPaper Command-Line Interface Tool")

    # Add subparsers for subcommands
    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    """""""""""""""
    [USE CASE] Sub-command: Create
    > python3 {main_python_file} create {filename} [-p {filepath}]
    > e.g. python3 main.py create file.taskpaper
    > e.g. python3 main.py create file.taskpaper -p /Users/username/Documents
    """""""""""""""
    create_parser = subparsers.add_parser("create", help="Create a new TaskPaper file")
    create_parser.add_argument("file_name", help="Path to the TaskPaper file to open")
    create_parser.add_argument("-p", "--path", help="File path to save the TaskPaper file")

    """""""""""""""
    [USE CASE] Sub-command: Open
    > python3 {main_python_file} open {filepath + filename}
    > e.g. python3 main.py open /Users/username/Documents/file.taskpaper
    """""""""""""""
    open_parser = subparsers.add_parser("open", help="Open and read a TaskPaper file")
    open_parser.add_argument("file_path", help="Path to the TaskPaper file to open")

    """""""""""""""
    [USE CASE] Sub-command: add-project (adding new project)
    > python3 {main_python_file} add-project {projectname}
    > e.g. python3 main.py add-project "New Project"
    """""""""""""""
    add_prj_parser = subparsers.add_parser("add-project", help="Add a new project to the currently opened TaskPaper file")
    add_prj_parser.add_argument("project_name", help="Name of the new project to add")

    """""""""""""""
    [USE CASE] Sub-command: list-projects (listing all projects)
    > python3 {main_python_file} list-projects
    > e.g. python3 main.py list-projects
    """""""""""""""
    ls_prj_parser = subparsers.add_parser("list-projects", help="List all projects from the currently opened TaskPaper file")

    """""""""""""""
    [USE CASE] Sub-command: rename-project (renaming a project)
    > python3 {main_python_file} rename-project {old_prjname} {new_prjname}
    > e.g. python3 main.py rename-project "old project name" "new project name"
    """""""""""""""
    rename_prj_parser = subparsers.add_parser("rename-project", help="Rename an existing project")
    rename_prj_parser.add_argument("old_name", help="The current name of the project to rename")
    rename_prj_parser.add_argument("new_name", help="The new name for the project")

    """""""""""""""
    [USE CASE] Sub-command: add-task (adding new task)
    > python3 {main_python_file} add-task --project {project} --task {task}
    > e.g. python3 main.py add-task --project "Project Name" --task "task name"
    """""""""""""""
    add_task_parser = subparsers.add_parser("add-task", help="Add a new task to an existing project in the currently opened TaskPaper file")
    add_task_parser.add_argument('--project', required=True, help='The name of the project')
    add_task_parser.add_argument('--task', required=True, help='The name of the task to add')

    """""""""""""""
    [USE CASE] Sub-command: list-tasks (listing all tasks)
    > python3 {main_python_file} list-tasks --project {project}
    > e.g. python3 main.py list-tasks --project "Project Name"
    """""""""""""""
    ls_task_parser = subparsers.add_parser("list-tasks", help="List all tasks under a specific project from the currently opened TaskPaper file")
    ls_task_parser.add_argument('--project', required=True, help='The name of the project whose tasks to be listed')

    """""""""""""""
    [USE CASE] Sub-command: edit-task (editing a task)
    > python3 {main_python_file} edit-task --project {project}
    > e.g. python3 main.py edit-task --project "Project Name"
    > A list of tasks will be listed down and users will be prompted to choose from the list and give updated text
    """""""""""""""
    edit_task_parser = subparsers.add_parser("edit-task", help="Edit an existing task under a specific project interactively")
    edit_task_parser.add_argument('--project',required=True, help='The name of the project whose task to be edited')

    return parser
