"""
helpers/help_manager.py
Help Manager - printing help and do error handling.
"""

from termcolor import colored

# printing help
def show_help(parser):
    """
    Display dynamically generated help message from the argument parser.
    """
    parser.print_help()

# printing error messages in red color for readability
def show_error(message):
    print(colored(message, 'red'))

# printing warning messages in yellow color for user experience
def show_warning(message):
    print(colored(message, 'yellow'))

# printing success messages in green color for user experience
def show_success(message):
    print(colored(message, 'green'))