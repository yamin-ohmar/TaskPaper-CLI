"""
cli/main.py
TaskPaper CLI - Main Entry Point
Handles user input and initializes argument parsing and command handling.
"""
# To allow running as an executable
#!/usr/bin/env python3

import os
import sys

# importing own modules
sys.path.append(os.path.join(os.path.dirname(__file__), '../'))
from cli import argument_parser as arg_parser
from cli import command_handler as cmd_handler

def main():
    # Parse user inputs
    parser = arg_parser.parse_arguments()
    args = parser.parse_args()

    # Route commands
    cmd_handler.handle_command(args, parser)

if __name__ == "__main__":
    main()
