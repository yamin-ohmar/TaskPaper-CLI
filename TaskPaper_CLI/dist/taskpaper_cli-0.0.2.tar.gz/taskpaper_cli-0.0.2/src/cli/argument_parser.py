"""
cli/argument_parser.py
Argument Parser - Validates and parses command-line arguments for TaskPaper CLI.
"""

import argparse
import importlib.metadata
from termcolor import colored

# adding arguments (subcommands/options) and their help descriptions
def parse_arguments():
    # a parser object to handle command-line arguments
    parser = argparse.ArgumentParser(prog='TaskPaper', description="TaskPaper Command-Line Interface Tool", formatter_class=argparse.RawTextHelpFormatter)

    # retrieve version from installed package metadata
    package_version = importlib.metadata.version("taskpaper-cli")

    # Command: "TaskPaper --version" - prints the version and exit by using 'action'
    parser.add_argument('-V', '--version', action='version', version=f"TaskPaper CLI {package_version}")

    # Add subparsers for subcommands
    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    """""""""""""""
    [USE CASE] Sub-command: Create
    > python3 {main_python_file} create {filename} [-p {filepath}]
    > e.g. python3 main.py create file.taskpaper
    > e.g. python3 main.py create file.taskpaper -p /Users/username/Documents
    """""""""""""""
    help_text_create = "Create a new TaskPaper file\nUsage:\t" + \
        colored("TaskPaper create <file_name> [-p <file_path>]", "green")

    create_parser = subparsers.add_parser("create", help=help_text_create)
    create_parser.add_argument("file_name", help="Name of the new TaskPaper file to be created")
    create_parser.add_argument("-p", "--path", help="File path to save the TaskPaper file")

    """""""""""""""
    [USE CASE] Sub-command: Open
    > python3 {main_python_file} open {filepath + filename}
    > e.g. python3 main.py open /Users/username/Documents/file.taskpaper
    """""""""""""""
    help_text_open = "Open to read a TaskPaper file\nUsage:\t" + \
        colored("TaskPaper open <file_path>", "green")

    open_parser = subparsers.add_parser("open", help=help_text_open)
    open_parser.add_argument("file_path", help="Path to the TaskPaper file to open")

    """""""""""""""
    [USE CASE] Sub-command: add-project (adding new project)
    > python3 {main_python_file} add-project {projectname}
    > e.g. python3 main.py add-project "New Project"
    """""""""""""""
    help_text_addProj = "Add a new project to the currently opened TaskPaper file\nUsage:\t" + \
        colored("TaskPaper add-project <project_name>", "green")

    add_prj_parser = subparsers.add_parser("add-project", help=help_text_addProj)
    add_prj_parser.add_argument("project_name", help="Name of the new project to add")

    """""""""""""""
    [USE CASE] Sub-command: list-projects (listing all projects)
    > python3 {main_python_file} list-projects
    > e.g. python3 main.py list-projects
    """""""""""""""
    help_text_listProj = "List all projects from the currently opened TaskPaper file\nUsage:\t" + \
        colored("TaskPaper list-projects", "green")
    
    ls_prj_parser = subparsers.add_parser("list-projects", help=help_text_listProj)

    """""""""""""""
    [USE CASE] Sub-command: rename-project (renaming a project)
    > python3 {main_python_file} rename-project {old_prjname} {new_prjname}
    > e.g. python3 main.py rename-project "old project name" "new project name"
    """""""""""""""
    help_text_renameProj = "Rename an existing project from the currently opened TaskPaper file\nUsage:\t" + \
        colored("TaskPaper rename-project <old_name> <new_name>", "green")
    
    rename_prj_parser = subparsers.add_parser("rename-project", help=help_text_renameProj)
    rename_prj_parser.add_argument("old_name", help="The current name of the project to rename")
    rename_prj_parser.add_argument("new_name", help="The new name for the project")

    """""""""""""""
    [USE CASE] Sub-command: delete-project (deleting a project)
    > python3 {main_python_file} delete-project {projectname}
    > e.g. python3 main.py delete-project "Old Project"
    """""""""""""""
    help_text_delProj = "Delete an existing project from the currently opened TaskPaper file\nUsage:\t" + \
        colored("TaskPaper delete-project <project_name>", "green")

    del_prj_parser = subparsers.add_parser("delete-project", help=help_text_delProj)
    del_prj_parser.add_argument("project_name", help="Name of the new project to be deleted")

    """""""""""""""
    [USE CASE] Sub-command: add-task (adding new task)
    > python3 {main_python_file} add-task --project {project} --task {task}
    > e.g. python3 main.py add-task --project "Project Name" --task "task name"
    """""""""""""""
    help_text_addTask = "Add a new task to an existing project in the currently opened TaskPaper file\nUsage:\t" + \
        colored("TaskPaper add-task -p <project> -t <task>", "green")
    
    add_task_parser = subparsers.add_parser("add-task", help=help_text_addTask)
    add_task_parser.add_argument('-p', '--project', required=True, help='The name of the project')
    add_task_parser.add_argument('-t', '--task', required=True, help='The name of the task to add')

    """""""""""""""
    [USE CASE] Sub-command: list-tasks (listing all tasks)
    > python3 {main_python_file} list-tasks --project {project}
    > e.g. python3 main.py list-tasks --project "Project Name"
    """""""""""""""
    help_text_listTasks = "List all tasks under a specific project from the currently opened TaskPaper file\nUsage:\t" + \
        colored("TaskPaper list-tasks -p <project>", "green")
    
    ls_task_parser = subparsers.add_parser("list-tasks", help=help_text_listTasks)
    ls_task_parser.add_argument('-p', '--project', required=True, help='The name of the project whose tasks to be listed')

    """""""""""""""
    [USE CASE] Sub-command: edit-task (editing a task)
    > python3 {main_python_file} edit-task --project {project}
    > e.g. python3 main.py edit-task --project "Project Name"
    > A list of tasks will be listed down and users will be prompted to choose from the list and give updated text
    """""""""""""""
    help_text_editTask = "Edit an existing task under a specific project interactively\nUsage:\t" + \
        colored("TaskPaper edit-task -p <project>\n", "green") + \
        "\tA list of tasks will be listed with a prompt\n\tKey in:\t" + \
        colored("<task_index> <updated_task>", "green")
    
    desc_text_editTask = "Flow:\t" + \
        colored("TaskPaper edit-task -p <project>\n", "green") + \
        "\tA list of tasks will be listed with a prompt\n\tKey in:\t" + \
        colored("<task_index> <updated_task>", "green")
    
    edit_task_parser = subparsers.add_parser("edit-task", description=desc_text_editTask, help=help_text_editTask,
                                             formatter_class=argparse.RawTextHelpFormatter)
    edit_task_parser.add_argument('-p', '--project',required=True, help='The name of the project whose task to be edited')

    """""""""""""""
    [USE CASE] Sub-command: delete-task
    > python3 {main_python_file} delete-task --project {project}
    > e.g. python3 main.py delete-tasks --project "Project Name"
    > A list of tasks will be listed down and users will be prompted to choose from the list to delete
    """""""""""""""
    help_text_delTask = "Delete an existing task under a specific project interactively\nUsage:\t" + \
        colored("TaskPaper delete-task -p <project>\n", "green") + \
        "\tA list of tasks will be listed with a prompt\n\tKey in:\t" + \
        colored("<task_index>", "green")
    
    desc_text_delTask = "Flow:\t" + \
        colored("TaskPaper delete-task -p <project>\n", "green") + \
        "\tA list of tasks will be listed with a prompt\n\tKey in:\t" + \
        colored("<task_index>", "green")
    
    delete_task_parser = subparsers.add_parser("delete-task", description=desc_text_delTask, help=help_text_delTask,
                                             formatter_class=argparse.RawTextHelpFormatter)
    delete_task_parser.add_argument('-p', '--project',required=True, help='The name of the project whose task to be deleted')

    return parser
